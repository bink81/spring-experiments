package com.marzeta.ordering.services;

public class ExampleOrder {
}
