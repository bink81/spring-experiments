package com.marzeta.ordering.services;

public interface ExampleOrderService {

}
