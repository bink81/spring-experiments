package com.marzeta.ordering.services;

public class ExampleOrderServiceBean implements ExampleOrderService {

}
